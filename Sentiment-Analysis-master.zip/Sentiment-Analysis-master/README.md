# Sentiment-Analysis
Sentiment analysis of tweets of Modi Government
